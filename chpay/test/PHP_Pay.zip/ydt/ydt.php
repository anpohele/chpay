<?php

include 'ydt_demo.php';

/**
 * 银贷通代收签约协议接口,本页面仅作接口测试。
 */
$ydt->get_ydt();



