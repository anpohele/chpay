<?php

include "division_demo.php";

/**
 * ���˲�ѯ
 */
$division->division_query();