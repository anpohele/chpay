<?php

include 'division_demo.php';

/**
 * 说明 分账登记
 */
$division->division_accept();