<?php

include "division_demo.php";

/**
 * 分账退款登记
 */
$division->division_refund_enrollment();