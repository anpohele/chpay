<?php

include 'pay_demo.php';

/**
 * 仅作接口测试 余额查询接口
 */
$pay->balance_query();