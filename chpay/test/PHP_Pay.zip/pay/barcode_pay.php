<?php

include "pay_demo.php";

/**
 * 反扫
 */
$pay->barcode_pay();