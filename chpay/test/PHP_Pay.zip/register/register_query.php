<?php

include "register_demo.php";

/**
 * 注册查询
 */
$register->register_query();