<?php

include 'dsf_demo.php';

/**
 * 说明：批量代付(银行卡)明细查询
 */
$dsf->batch_df_query();