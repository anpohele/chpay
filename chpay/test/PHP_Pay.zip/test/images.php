<?php

include '../demo.php';

/**
 * 二要素带返照接口返回的加密字段
 */

$s = new demo();
$s->base64toimages("二要素带返照接口返回的加密字段");