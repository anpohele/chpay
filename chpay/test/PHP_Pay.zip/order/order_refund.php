<?php

include "order_demo.php";

/**
 * 订单退款
 */
$order->order_refund("20190306142659", "02O190306138617245", "0.02",
    "交易退款");