<?php

include "division_demo.php";

/**
 * 分账退款
 */
$division->division_refund();