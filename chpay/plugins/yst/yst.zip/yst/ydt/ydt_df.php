<?php

include 'ydt_demo.php';

/**
 * 银贷通付款
 */
$ydt->ydt_df();