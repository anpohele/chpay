<?php

include "register_demo.php";

/**
 * 注册获取token
 */
$register->get_token();