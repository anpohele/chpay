<?php

include 'order_demo.php';

/**
 * 仅作接口测试 通用订单查询接口
 */
$order->common_order_query();