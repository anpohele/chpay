<?php

include 'order_demo.php';

/**
 * 订单查询
 */
$order->order_query("20190124094240", "02O190124118079224");
