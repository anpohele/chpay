<?php

include 'order_demo.php';

/**
 * 说明:订单对账单下载
 */
$order->bill_down();